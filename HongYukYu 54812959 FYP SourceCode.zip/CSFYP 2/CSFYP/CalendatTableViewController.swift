//
//  CalendatTableViewController.swift
//  CSFYP
//
//  Created by Lok Lam Kwong on 30/10/2019.
//  Copyright © 2019 Hong Yuk Yu. All rights reserved.
//

import UIKit
import Firebase

class CalendatTableViewController: UITableViewController,  UICollectionViewDataSource, UICollectionViewDelegate , UICollectionViewDelegateFlowLayout {

        let db = Firestore.firestore()
        var currentYear = Calendar.current.component(.year, from: Date())
        var currentMonth = Calendar.current.component(.month, from: Date())
        var months = ["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"]
        var NumberOfDaysInThisMonth:Int{
            let dateComponents = DateComponents(year: currentYear , month: currentMonth)
            let date = Calendar.current.date(from: dateComponents)!
            let range = Calendar.current.range(of: .day, in: .month, for: date)
            return range?.count ?? 0
        }
        var whatDayIsIt:Int{
            let dateComponents = DateComponents(year: currentYear , month: currentMonth)
            let date = Calendar.current.date(from: dateComponents)!
            return Calendar.current.component(.weekday, from: date)
        }
        var howManyItemsShouldIAdd:Int{
            return whatDayIsIt - 1
        }
        var EachMonthDateWithRecord = [String]()
        var LabelArray = [String]()
        
        @IBOutlet weak var calendar: UICollectionView!
        @IBOutlet weak var timeLabel: UILabel!
        @IBOutlet weak var LastMonth: UIButton!
        @IBOutlet weak var NextMonth: UIButton!
        @IBOutlet weak var Background: UIImageView!

        
        
       func numberOfSections(in collectionView: UICollectionView) -> Int {
            return 1
        }
        
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return NumberOfDaysInThisMonth + howManyItemsShouldIAdd
        }
        
        var ArrayElementNumber = 0
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
     
        
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"cell", for: indexPath)
            

            
            if let textlabel = cell.contentView.subviews[0] as? UILabel{
               // let  textlabel2 = cell.contentView.subviews[1] as? UILabel
                if indexPath.row < howManyItemsShouldIAdd{
                    textlabel.text = ""
                }
                else{
                    
                    let dateOfCell = (indexPath.row + 1 - howManyItemsShouldIAdd)
                   /* if EachMonthDateWithRecord.contains("\(dateOfCell)")
                    {
                        print("Now is \(dateOfCell) and record is found")
                        switch LabelArray[ArrayElementNumber] {
                        case "Positive": cellimage.image = UIImage(named: "icon40")  ;
                        case "Negative": cellimage.image = UIImage(named: "icon40");
                        case "Neutral": cellimage.image = UIImage(named: "icon40") ;
                        default:
                            textlabel.text = ("\(dateOfCell)")
                        }
                        textlabel.text = ("\(dateOfCell)");
                        //textlabel.text = ("\(dateOfCell) \n\(LabelArray[ArrayElementNumber])")
                        //textlabel.text = "😀"
                        //\n\(LabelArray[ArrayElementNumber]
                        print("\(ArrayElementNumber)")
                        ArrayElementNumber += 1
                       
                    
                    }else{
                        print("Now is \(dateOfCell) and record is not found")
                        textlabel.text = "\(dateOfCell)"
                        
                    }*/
                    textlabel.text = "\(dateOfCell)"
                }

                
            }
            
            if let cellimage = cell.contentView.subviews[1] as? UIImageView{
                
                 cellimage.image = UIImage(named: "Empty")
                if indexPath.row < howManyItemsShouldIAdd{
                              //print("show nothing!")
                           }
                           else{
                               
                               let imageOfCell = (indexPath.row + 1 - howManyItemsShouldIAdd)
                               if EachMonthDateWithRecord.contains("\(imageOfCell)")
                               {
                                   print("Now is \(imageOfCell) and record is found --- \(LabelArray[ArrayElementNumber] )")
                                   /*var testString = String(LabelArray[ArrayElementNumber])
                                    print(testString == "[Neutral]")
                                   print(LabelArray[ArrayElementNumber] == "[Positive]")
                                   print(LabelArray[ArrayElementNumber] == "Negative")
                                   print(LabelArray[ArrayElementNumber] == "Neutral")*/
                                
                                
                                   switch LabelArray[ArrayElementNumber] {
                                   case "[Positive]": cellimage.image = UIImage(named: "Positive") ;
                                   case "[Negative]": cellimage.image = UIImage(named: "Negative");
                                   case "[Neutral]": cellimage.image = UIImage(named: "Neutral") ;
                                   default:
                                    print("something wired!");
                                }
                                 
                                   print("\(ArrayElementNumber)")
                                   ArrayElementNumber += 1
                               
                               }
                           }
            }

                return cell
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return 0
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return 0
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let width = collectionView.frame.width / 7
            return CGSize(width: width, height: 70)
        }
        
        override func viewWillLayoutSubviews() {
            super.viewWillLayoutSubviews()
            calendar.collectionViewLayout.invalidateLayout()
            calendar.reloadData()
        }
        

        
        
        override func viewDidLoad() {
            super.viewDidLoad()
          //  gifimage.loadGif(name: "gifitem2")
           //Background.loadGif(name: "CalendarBG")
            // Do any additional setup after loading the view.
             
            setup()
        }
        
        func setup(){
            
            timeLabel.text = "\(currentYear)年" + months[currentMonth - 1 ]
            
            self.EachMonthDateWithRecord.removeAll()
            self.LabelArray.removeAll()
                
                db.collection("/Record/\(currentYear)/\(currentMonth)").getDocuments() { (querySnapshot, err) in
                if let err = err {
                    print("Error getting documents: \(err)")
                } else {
                    for document in querySnapshot!.documents {
                        print("\(document.documentID) => \(document.data())")
                        self.EachMonthDateWithRecord.append(document.documentID)
                        self.LabelArray.append("\(document.data().values)")
                        print("\(document.data().values)")
                        self.calendar.reloadData()
                       // print("\(document.documentID) => \(document.data())")
                        //dump(self.EachMonthDateWithRecord)
                        dump(self.LabelArray)
                    }
                }
            }
                print("Now is month \(currentMonth)!")
                print("check db!")
            ArrayElementNumber = 0
            
            // calendar.reloadData()
    }
        
       /* @IBAction func ClickLastMonth(_ sender: UIButton) {
            currentMonth -= 1
            if currentMonth == 0{
                currentMonth = 12
                currentYear -= 1
            }
            setup()
        }
        
        @IBAction func ClickNextMonth(_ sender: UIButton) {
            currentMonth += 1
            if currentMonth == 13{
                currentMonth = 1
                currentYear += 1
            }
            setup()
        }*/
        /*
        // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
        }
        */
}
