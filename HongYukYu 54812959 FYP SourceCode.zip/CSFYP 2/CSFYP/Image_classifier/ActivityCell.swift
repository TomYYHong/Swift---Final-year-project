//
//  ActivityCell.swift
//  CSFYP
//
//  Created by Yuk Yu Hong on 19/3/2020.
//  Copyright © 2020 Hong Yuk Yu. All rights reserved.
//

import UIKit

class ActivityCell: UITableViewCell {
    @IBOutlet weak var Label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
