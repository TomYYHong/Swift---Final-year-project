//
//  DateCell.swift
//  CSFYP
//
//  Created by Yuk Yu Hong on 22/3/2020.
//  Copyright © 2020 Hong Yuk Yu. All rights reserved.
//

import UIKit

class DateCell: UICollectionViewCell {
    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var Image: UIImageView!
    
}
