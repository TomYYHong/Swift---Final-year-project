//
//  ImageClassificationViewController.swift
//  CSFYP
//
//  Created by Yuk Yu Hong on 23/10/2019.
//  Copyright © 2019 Hong Yuk Yu. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class ImageClassificationViewController: UIViewController ,UINavigationControllerDelegate ,UIImagePickerControllerDelegate {
    
    @IBOutlet weak var ChangeResultButton: UIButton!
    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var ImageLabel: UILabel!
    @IBOutlet weak var ImageButton: UIButton!
   // @IBOutlet weak var UploadButton: UIButton!
    @IBOutlet weak var LoadingGIF: UIImageView!
    @IBOutlet weak var LoadingBackground: UIView!
    
    //Check is result ready
    var HasResult = false
    
    //return the size of full screen
    let fullScreenSize = UIScreen.main.bounds.size
    
    //connect to firestore and storage
    let db = Firestore.firestore()
    let storage = Storage.storage()
    
    //to recieve the predict result
    var FinalResult = ""
 
    //set up image classifier model
    let mlModel = face6()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set up gif
        ImageView.loadGif(name: "gifcat2")
        LoadingGIF.loadGif(name: "loading")
        LoadingGIF.isHidden = true;
        LoadingBackground.isHidden = true
        ChangeResultButton.isHidden = true
       // self.view.backgroundColor = UIColor(patternImage: UIImage(named: "想知你心")!)
        // Do any additional setup after loading the view.
    }
    
    //select photop
    @IBAction func selectphoto(_ sender: UIButton) {
         importFromCameraRoll()
    }
    
    // Access to photolibrary
    func importFromCameraRoll() {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
   
    @IBAction func NextPage(_ sender: Any) {
        if HasResult == true{
            print("Next page!")
            performSegue(withIdentifier: "GoActivities", sender: nil)
            
        }
        else{
            let controller = UIAlertController(title: "未有選擇照片", message: "你仲未揀相呀！", preferredStyle: .alert)
                       let okAction = UIAlertAction(title: "好", style: .default, handler: nil)
                       controller.addAction(okAction)
                       present(controller, animated: true, completion: nil)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "GoActivities" {
            
            let vc = segue.destination as! ActivitesViewController
         vc.ImageView = self.ImageView
            vc.result = self.FinalResult

        }
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
       didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
         guard  let image = info[.originalImage] as? UIImage else{
                   print("failed buffer")
           return
           }
           
        if let image = info[.editedImage] as? UIImage
               {
                   ImageView.image = image

               }
               else if let image = info[.originalImage] as? UIImage
               {
                   ImageView.image = image
               }
           //Show the image in the imageview
           //ImageView.image = image
        //picker.dismiss(animated: true,completion: nil)
        
           if let buffer = image.buffer(with: CGSize(width:224, height:224)) {
               guard let prediction = try? mlModel.prediction(image: buffer) else {fatalError("Unexpected runtime error")}
            var Resultstring = ""
            
            //handle the predict result
            
            //the prob is \(prediction.classLabelProbs).
            switch(prediction.classLabel){
            case ("Positive"): Resultstring = "你睇落去係咁：  😀 " ; FinalResult = prediction.classLabel ; HasResult = true;
            case ("Neutral"):Resultstring = "你睇落去係咁： 🙂 ";
            FinalResult = prediction.classLabel ; HasResult = true;
            case ("Negative"): Resultstring = "你睇落去係咁： ☹️ ";
            FinalResult = prediction.classLabel ; HasResult = true;
                
            default: Resultstring = "對唔住呀，我睇唔明你嘅表情.🤖";
            print(FinalResult)
            }
            
            //Print the predict result
            ImageLabel.text = Resultstring
            self.ChangeResultButton.isHidden = false
           
            
           
        //dismiss the image picker
           dismiss(animated:true, completion: nil)
            
            //Alert user to change record or not after image uploaded
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            let Delaycontroller = UIAlertController(title: "結果正唔正確？", message: "需唔需要更改結果?", preferredStyle: .alert)
            //confirmed to change label
            let DelayokAction = UIAlertAction(title: "要", style: .default) { (_) in
                self.ChangeResult()
            }
            Delaycontroller.addAction(DelayokAction)
            let DelaycancelAction = UIAlertAction(title: "唔駛", style: .cancel, handler: nil)
            Delaycontroller.addAction(DelaycancelAction)
            self.present(Delaycontroller, animated: true, completion: nil)
            }
       }
    }
    
    
    
    //After selected to change result, a alert window will be shown
    func ChangeResult(){
        var ChangedResult = ""
        let Changecontroller = UIAlertController(title: "咁你真正嘅心情係？", message: "請揀選以下其中一個選項：", preferredStyle: .actionSheet)
        let names = ["😀", "🙂", "☹️"]
        for name in names {let Changeaction = UIAlertAction(title: name, style: .default) { (Changeaction) in
            ChangedResult = Changeaction.title ?? ""
            print(Changeaction.title!)
            
            var changedResult = ""
            //pop up three options for user to change
            switch (Changeaction.title) {
            case ("😀") : self.FinalResult = "Positive"
            changedResult = "你睇落去係咁：  😀 ";
            case ("🙂") : self.FinalResult = "Neutral"
                changedResult = "你睇落去係咁： 🙂 ";
            case ("☹️") : self.FinalResult = "Negative"
            changedResult = "你睇落去係咁： ☹️ "
                ;
            case .none:
                print("Somthing Wrong!");
            case .some(_):
                print ("Some?");
            }
            
            //Label updated to the changed result
            self.ImageLabel.text = changedResult
            print(self.FinalResult)
            
            //Inform the user the result have been changed
            let controller = UIAlertController(title: "已更改結果", message: "你嘅結果已經更改做\(ChangedResult)！", preferredStyle: .alert)
                       let okAction = UIAlertAction(title: "好", style: .default, handler: nil)
                       controller.addAction(okAction)
            self.present(controller, animated: true, completion: nil)
                         }
                         Changecontroller.addAction(Changeaction)
                      }
        
            
            let ChangecancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
            Changecontroller.addAction(ChangecancelAction)
            present(Changecontroller, animated: true, completion: nil)
    }
    @IBAction func ClickChangeResultButton(_ sender: Any) {
        self.ChangeResult()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
